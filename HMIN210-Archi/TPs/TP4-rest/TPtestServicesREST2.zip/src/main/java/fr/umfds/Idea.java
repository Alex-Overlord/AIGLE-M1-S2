package fr.umfds;

public class Idea {
    private String text;

    public Idea() {}

    public Idea(String text) {
        this.text = text;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
