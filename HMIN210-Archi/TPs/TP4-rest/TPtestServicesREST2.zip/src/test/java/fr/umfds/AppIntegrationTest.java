package fr.umfds;

import org.glassfish.jersey.client.JerseyWebTarget;
import org.glassfish.jersey.jackson.JacksonFeature;
import org.glassfish.jersey.logging.LoggingFeature;
import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.test.JerseyTest;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import javax.ws.rs.Path;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Application;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;
import java.util.logging.Level;

public class AppIntegrationTest extends JerseyTest {

    @Override
    protected Application configure() {
        ResourceConfig resourceConfig = new ResourceConfig(BrainstormResource.class);
        resourceConfig.property(LoggingFeature.LOGGING_FEATURE_LOGGER_LEVEL_SERVER, Level.WARNING.getName());
        return resourceConfig;
    }

    @Test
    public void testGetBrainstorms() {
        // Given
        Client client = ClientBuilder.newClient();
        WebTarget target = client.target("http://localhost:8080/rest/brainstorms");

        // When
        Response response = target.request(MediaType.APPLICATION_JSON_TYPE).get();

        // Then
        Assertions.assertEquals(Response.Status.OK.getStatusCode(), response.getStatus(),
                "Http Response should be 200: ");
        List<Brainstorm> readEntities = response.readEntity(new GenericType<>() {});
        Assertions.assertNotNull(readEntities);
        Assertions.assertEquals(3, readEntities.size());
        Assertions.assertTrue(readEntities.stream().anyMatch(current -> current.getId()==1));
    }
}
